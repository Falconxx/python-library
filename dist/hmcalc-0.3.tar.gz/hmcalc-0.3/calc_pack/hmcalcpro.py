#!/usr/bin/python2.7

def tiles(area, tile):
	return area / tile

	
def paint(area, performance):
	return area / performance
	
def panels(area, panel):
	return area / panel
