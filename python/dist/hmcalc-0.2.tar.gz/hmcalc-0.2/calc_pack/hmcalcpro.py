#!/usr/bin/python

def tiles(area, tile):
	return area / tile

	
def paint(area, performance):
	return area / performance
	
def panels(area, panel):
	return area / panel